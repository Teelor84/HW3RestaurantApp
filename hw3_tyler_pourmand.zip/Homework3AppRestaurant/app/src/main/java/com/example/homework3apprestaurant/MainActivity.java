package com.example.homework3apprestaurant;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ShareCompat;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
//Welcome Page


public class MainActivity extends AppCompatActivity {

    private Button entermenubutton;
    private Button openmapbutton;
    private Button sharebutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        entermenubutton = (Button) findViewById(R.id.enter_menu_button);
        entermenubutton.setOnClickListener(enterMenuListener);

        openmapbutton = (Button) findViewById(R.id.open_map_button);
        openmapbutton.setOnClickListener(openLocationListener);

        sharebutton = (Button) findViewById(R.id.share_button);
        sharebutton.setOnClickListener(shareListener);
    }

    //enter menu
    public View.OnClickListener enterMenuListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            Intent entermenuintent = new Intent(getApplicationContext(), Menu.class);
            startActivity(entermenuintent);
        }
    };

    //map opener
    public View.OnClickListener openLocationListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Uri locationaddress = Uri.parse("geo: 41.630477041112805, -71.0064787055404?q= UMass Dartmouth");

            Intent mapintent = new Intent(Intent.ACTION_VIEW, locationaddress);

            try{
                startActivity(mapintent);
            } catch (ActivityNotFoundException e){
                Log.d("mapsIntent", "Can't handle Google Maps Intent");
            }
        }
    };

    public View.OnClickListener shareListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            String address = "285 Old Wesport Rd, North Dartmouth, MA, 02747";

            ShareCompat.IntentBuilder shareIntentBuilder = new ShareCompat.IntentBuilder(MainActivity.this);

            shareIntentBuilder.setType("text/plain");
            shareIntentBuilder.setChooserTitle("Share this restaurant with: ");
            shareIntentBuilder.setText(address);
            shareIntentBuilder.startChooser();


        }
    };
}