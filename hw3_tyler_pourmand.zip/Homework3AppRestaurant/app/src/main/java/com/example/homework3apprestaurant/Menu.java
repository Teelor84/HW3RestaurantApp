package com.example.homework3apprestaurant;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Menu extends AppCompatActivity {

    private ImageButton decrementcurrybutton;
    private ImageButton incrementcurrybutton;
    private ImageButton decrementcakebutton;
    private ImageButton incrementcakebutton;
    private FloatingActionButton checkoutbutton;
    EditText numofcurry;
    EditText numofcake;

    //request code required in order to receive number of items back from third activity even though they didn't change
    private final static int MY_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);


        decrementcurrybutton = (ImageButton) findViewById(R.id.removeCCbutton);
        decrementcurrybutton.setOnClickListener(decrementCurryListener);

        incrementcurrybutton = (ImageButton) findViewById(R.id.addCCbutton);
        incrementcurrybutton.setOnClickListener(incrementCurryListener);

        decrementcakebutton = (ImageButton) findViewById(R.id.removeLCbutton);
        decrementcakebutton.setOnClickListener(decrementCakeListener);

        incrementcakebutton = (ImageButton) findViewById(R.id.addLCbutton);
        incrementcakebutton.setOnClickListener(incrementCakeListener);

        numofcurry = (EditText) findViewById(R.id.CCcounteredittext);
        numofcake = (EditText) findViewById(R.id.LCcounteredittext);

        checkoutbutton = (FloatingActionButton) findViewById(R.id.checkoutbutton);
        checkoutbutton.setOnClickListener(checkoutFabListener);




    }
    //decrement the amount of curry in the edittext
    public View.OnClickListener decrementCurryListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            //convert edittext to an int
            String currycounter = numofcurry.getText().toString();
            int curryedittextvalue = Integer.parseInt(currycounter);
            if(curryedittextvalue >0){
                numofcurry.setText(String.valueOf(curryedittextvalue-1));
            }


        }
    };
    //increment the amount of curry in the edittext
    public View.OnClickListener incrementCurryListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            //convert edittext to an int
            String currycounter = numofcurry.getText().toString();
            try{
                int curryedittextvalue = Integer.parseInt(currycounter);
                numofcurry.setText(String.valueOf(curryedittextvalue+1));
            } catch (NumberFormatException e){
                Log.d("incrementcurry", "Curry cannot be incremented");
            }

        }
    };



    //decrement the amount of lava cake in edittext
    public View.OnClickListener decrementCakeListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            //convert edittext to an int
            String cakecounter = numofcake.getText().toString();
            int cakeedittextvalue = Integer.parseInt(cakecounter);
            //if value is positive then decrement it
            if(cakeedittextvalue > 0){
                numofcake.setText(String.valueOf(cakeedittextvalue-1));
            }
        }
    };
    //increment the amount of lava cake in the edittext
    public View.OnClickListener incrementCakeListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            //convert edittext to an int
            String cakecounter = numofcake.getText().toString();
            try{
                int cakeedittextvalue = Integer.parseInt(cakecounter);
                numofcake.setText(String.valueOf(cakeedittextvalue+1));
            } catch (NumberFormatException e){
                Log.d("incrementcake", "Cake cannot be incremented");
            }

        }
    };

    //floating action button that takes you to third activity and brings the
    //number of chicken curries and lava cakes with it
    public View.OnClickListener checkoutFabListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            String currycounter = numofcurry.getText().toString();
            int curryedittextvalue = Integer.parseInt(currycounter);
            String cakecounter = numofcake.getText().toString();
            int cakeedittextvalue = Integer.parseInt(cakecounter);
            Intent checkoutintent = new Intent(getApplicationContext(), CheckOut.class);

            checkoutintent.putExtra("NumofCurry", curryedittextvalue);
            checkoutintent.putExtra("NumofCake", cakeedittextvalue);
            startActivityForResult(checkoutintent, 1);

        }
    };

    //method to get the values back from the third activity and send them
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent menuintent){
        super.onActivityResult(requestCode, resultCode, menuintent);
        if(requestCode == Activity.RESULT_OK){
            if(resultCode == MY_REQUEST_CODE){
                if(menuintent != null){
                    numofcurry.setText(menuintent.getStringExtra(String.valueOf("ReturnedCurry")));
                    numofcake.setText(menuintent.getStringExtra(String.valueOf("ReturnedCake")));
                }

            }
        }
    }


}