package com.example.homework3apprestaurant;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import org.w3c.dom.Text;

import java.text.DecimalFormat;

public class CheckOut extends AppCompatActivity {


    private RadioButton tip15;
    private RadioButton tip20;

    double totalcost;

    //initialized outside onCreate so they can be global, but the values are changed in onCreate which carries into other methods
    int numofcurry = 0;
    int numofcake = 0;

    EditText customtipedittext;

    private Button edititemsbutton;
    private Button submitorderbutton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_out);

        //get content from intent
        Bundle extras = getIntent().getExtras();
        numofcurry = extras.getInt("NumofCurry");
        numofcake = extras.getInt("NumofCake");

        //calculate total cost within onCreate for the initial, no tip cost
        totalcost = (11.50 * numofcurry) + (7.25 * numofcake);



        //setting price text and getting total cost for radio buttons
        TextView chickencurryprice = (TextView) findViewById(R.id.chickencurrypricetext);
        chickencurryprice.setText("$11.50 x " + numofcurry);
        TextView lavacakeprice = (TextView) findViewById(R.id.lavacakepricetext);
        lavacakeprice.setText("$7.25 x " + numofcake);
        TextView totalcostprice = (TextView) findViewById(R.id.totalcosttext);
        totalcostprice.setText(String.format("$%.2f", totalcost));

        //setting tip costs and amount
        TextView tipsamount = (TextView) findViewById(R.id.tipstotaltext);
        tipsamount.setText("Tips: None");
        TextView tipstotalcost = (TextView) findViewById(R.id.tipstotalcosttext);
        tipstotalcost.setText("$0.00");

        //setting initial final cost before tips
        TextView finaltotalcosttext = (TextView) findViewById(R.id.finaltotalcost);
        finaltotalcosttext.setText(String.format("$%.2f", totalcost));

        //establishment of radio buttons and their listeners
        tip15 = (RadioButton) findViewById(R.id.tipbutton15);
        tip15.setOnClickListener(RadioButtonListener);

        tip20 = (RadioButton) findViewById(R.id.tipbutton20);
        tip20.setOnClickListener(RadioButtonListener);

        //edittext setup for custom tip
        customtipedittext = (EditText) findViewById(R.id.customtipedittext);
        customtipedittext.addTextChangedListener(customtipWatcher);

        //edititems button establishment
        edititemsbutton = (Button) findViewById(R.id.editorderbutton);
        edititemsbutton.setOnClickListener(editItemsListener);

        submitorderbutton = (Button) findViewById(R.id.submitorderbutton);
        submitorderbutton.setOnClickListener(submitOrderListener);
    }

    //onclick listener for tip radio buttons
    private View.OnClickListener RadioButtonListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            //check which radio button is selected
            boolean checked = ((RadioButton) view).isChecked();

            switch(view.getId()){
                case R.id.tipbutton15:
                    if(checked){
                        TextView tipsamount = (TextView) findViewById(R.id.tipstotaltext);
                        tipsamount.setText("Tips(15%)");

                        TextView tipstotalcost = (TextView) findViewById(R.id.tipstotalcosttext);
                        double tips = 15 * (totalcost/100);

                        //String tipsstring = String.valueOf(tips);
                        tipstotalcost.setText(String.format("$%.2f", tips));

                        TextView finaltotalcosttext = (TextView) findViewById(R.id.finaltotalcost);
                        finaltotalcosttext.setText(String.format("$%.2f", tips + totalcost));
                        break;
                    }
                case R.id.tipbutton20:
                    if(checked){
                        TextView tipsamount = (TextView) findViewById(R.id.tipstotaltext);
                        tipsamount.setText("Tips(20%)");

                        TextView tipstotalcost = (TextView) findViewById(R.id.tipstotalcosttext);
                        double tips = 20 * (totalcost/100);


                        tipstotalcost.setText(String.format("$%.2f", tips));

                        TextView finaltotalcosttext = (TextView) findViewById(R.id.finaltotalcost);
                        finaltotalcosttext.setText(String.format("$%.2f", totalcost + tips));

                        break;
                    }

            }

        }
    };

    private TextWatcher customtipWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            TextView tipsamount = (TextView) findViewById(R.id.tipstotaltext);
            //custom tip value parsing
            String customtipedittextvalue = customtipedittext.getText().toString();
            //if the edittext has no value then it will not parse the integer value of the edittext, thus
            //not causing a crash
            if(!customtipedittextvalue.equals("")){
                int customtip = Integer.parseInt(customtipedittextvalue);
                tipsamount.setText("Tips(" + customtipedittextvalue + "%):");

                TextView tipstotalcost = (TextView) findViewById(R.id.tipstotalcosttext);
                double tips = customtip * (totalcost/100);


                tipstotalcost.setText(String.format("$%.2f", tips));

                TextView finaltotalcosttext = (TextView) findViewById(R.id.finaltotalcost);
                finaltotalcosttext.setText(String.format("$%.2f", totalcost + tips));
            } else{
                tipsamount.setText("Tips: None");
                TextView tipstotalcost = (TextView) findViewById(R.id.tipstotalcosttext);
                tipstotalcost.setText("$0.00");

                TextView finaltotalcosttext = (TextView) findViewById(R.id.finaltotalcost);
                finaltotalcosttext.setText(String.format("$%.2f", totalcost));
            }

        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };


    //listener that sets quantity values again and passes them back to Menu in the form of strings
    private View.OnClickListener editItemsListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String currycheckout = Integer.toString(numofcurry);
            String cakecheckout = Integer.toString(numofcake);
            Intent menuintent = new Intent();
            menuintent.putExtra("ReturnedCurry", currycheckout);
            menuintent.putExtra("ReturnedCake", cakecheckout);
            setResult(RESULT_OK, menuintent);
            finish();
        }
    };

    //Listener for submit order snackbar
    private View.OnClickListener submitOrderListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Snackbar submitordersnackbar = Snackbar.make(view, "Your order has been submitted!", Snackbar.LENGTH_SHORT)
                    .setAction("UNDO", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Snackbar undosnackbar = Snackbar.make(view, "Your order has been canceled", Snackbar.LENGTH_SHORT);
                            undosnackbar.show();
                        }
                    });
            submitordersnackbar.show();

        }
    };



}