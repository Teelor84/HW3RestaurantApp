Tyler Pourmand
Restaurant App
This app is meant to simulate ordering from a restaurant that contains two items, chicken curry and 
lava cake. The app will allow the user to find the restaurant by opening google maps with a button or 
share the restaurant's address by allowing the user to copy it. When the user enters the menu they are 
able to enter a custom quantity of the items or use the appropriate buttons. On the checkout page the
total cost of the items is displayed. There is also the option to give a tip, either the precreated 
15% and 20% tip buttons or by entering a custom tip. The cost of the tip and that cost added to the cost
of the items is added together for a new final cost. The user is able to return to the previous menu where
the quantity of their items is maintained. They can also submit their order as well with a popup message 
confirming this and the ability to undo it in which case a message will confirm this cancellation. 